# DeepREAP

Reference implementation of the **DeepREAP** system from
*Efficient Cloud Resource Allocation: A Novel Integration of Predictive
Modeling and Reinforcement Learning* (Sharma, Gupta, Nagral,
Ramachandrapuram — SJSU CMPE-294, 2023). The original paper proposed
the architecture but did not implement it. This repository delivers a
working, end-to-end prototype:

1. **REAP** — accuracy-weighted regression ensemble (Linear, Bayesian
   Ridge, Decision Tree, Random Forest, SVR) with GA-based feature
   selection, predicting cluster CPU and memory demand.
2. **DeepRM_Plus** — CNN policy trained with imitation learning on an
   SJF expert and refined with PPO on a discrete-time cluster scheduling
   environment.
3. **DeepREAP integration** — REAP forecasts are appended as extra
   channels of the RL state image so the scheduler is aware of
   anticipated demand.
4. **REST API + monitoring** — FastAPI service exposing
   `/predict`, `/forecast`, `/schedule`, `/feedback`, `/metrics`,
   scraped by a Prometheus + Grafana stack defined in
   `docker-compose.yml`.
5. **Benchmark** — DeepREAP vs vanilla DeepRM_Plus vs SJF / FIFO /
   Packer baselines with metric plots.

## Layout

```
deep-reap/
├── data/                       # synthetic generator + datasets
├── src/
│   ├── reap/                   # ensemble + GA feature selection
│   ├── deeprm/                 # env, CNN, baselines, imitation, PPO
│   ├── integration/            # DeepREAP glue + FastAPI app
│   ├── monitoring/             # Prometheus metrics
│   └── evaluation/             # benchmark + plotting
├── scripts/                    # convenience entrypoints
├── config/                     # prometheus.yml + grafana provisioning
├── docker-compose.yml          # monitoring stack
├── tests/test_smoke.py         # end-to-end smoke tests
├── results/                    # benchmark.json + plots/  (generated)
├── models/                     # trained checkpoints       (generated)
└── report/REPORT.md            # methodology + results
```

## Quick start

```bash
pip install -r requirements.txt

# 1. one-shot pipeline (data → REAP → DeepRM_Plus → DeepREAP → benchmark)
python -m scripts.run_pipeline

# 2. run the API
python -m scripts.run_api
# -> http://127.0.0.1:8000/docs  (Swagger UI)

# 3. start monitoring (Prometheus + Grafana)
docker compose up -d
# -> Prometheus  http://127.0.0.1:9090
# -> Grafana     http://127.0.0.1:3000   (anonymous viewer enabled)
```

## Step-by-step usage

```bash
# generate synthetic workload
python -m data.synthetic_generator --hours 1440 --jobs 3000 --horizon 1500

# train REAP
python -m src.reap.train --target cpu_load
python -m src.reap.train --target memory_usage

# train vanilla DeepRM_Plus
python -m src.deeprm.train --reap-channels 0 \
    --imitation-episodes 30 --ppo-updates 15

# train DeepREAP (REAP forecast as extra channels)
python -m src.deeprm.train --reap-channels 2 \
    --imitation-episodes 30 --ppo-updates 15

# benchmark all schedulers and generate plots
python -m src.evaluation.benchmark
```

Artifacts:

```
models/reap/reap_cpu_load.joblib
models/reap/reap_memory_usage.joblib
models/deeprm/{deeprm_plus,deepreap}_imitation.pt   # post-imitation
models/deeprm/{deeprm_plus,deepreap}.pt              # post-PPO
results/benchmark.json
results/plots/*.png
```

## Tests

```bash
pytest -q
```

The smoke tests run every module on tiny inputs in under 10 seconds.

## API reference (summary)

| Method | Path        | Description                                         |
|--------|-------------|-----------------------------------------------------|
| GET    | /health     | Liveness + which models are loaded                  |
| POST   | /predict    | Single REAP prediction (CPU or memory)              |
| POST   | /forecast   | (channels, R, T) forecast tensor for the env state  |
| POST   | /schedule   | Action from the trained CNN policy                  |
| POST   | /feedback   | Report observed value to update REAP error metrics  |
| GET    | /metrics    | Prometheus exposition                               |

See `report/REPORT.md` for methodology, design decisions, and results.
# deap-reap
