"""
Fast smoke tests. They exercise the wiring of every module on tiny inputs;
they are NOT a substitute for the full benchmark.

Run with:
    pytest -q
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import torch

from data.synthetic_generator import generate_job_trace, generate_resource_usage
from src.deeprm.baselines import run_baseline
from src.deeprm.env import ClusterConfig, ClusterEnv
from src.deeprm.imitation import ImitationConfig, collect_expert_trajectories, train_imitation
from src.deeprm.network import CNNPolicy
from src.reap.feature_selection import GAConfig, select_features
from src.reap.ensemble import train_reap


def test_generators_shapes():
    df = generate_resource_usage(n_hours=48)
    assert len(df) == 48 * 4
    assert {"cpu_load", "memory_usage", "network_utilization"} <= set(df.columns)

    jobs = generate_job_trace(n_jobs=200, horizon=200)
    assert {"job_id", "arrival_time", "duration", "res_0", "res_1"} <= set(jobs.columns)


def test_ga_feature_selection_runs():
    rng = np.random.default_rng(0)
    X = rng.normal(size=(200, 8))
    # only features 1 and 4 matter
    y = 2.0 * X[:, 1] - 1.0 * X[:, 4] + rng.normal(scale=0.1, size=200)
    cfg = GAConfig(pop_size=10, n_generations=5, seed=0)
    mask, selected, fit = select_features(X, y, cfg=cfg)
    assert len(mask) == 8
    assert mask.sum() >= 2
    assert fit > -1e9


def test_reap_train_small():
    df = generate_resource_usage(n_hours=24 * 7)
    feats = ["hour_of_day", "day_of_week", "is_weekend", "active_users",
             "previous_hour_cpu", "network_utilization"]
    X = df[feats].to_numpy(dtype=float)
    y = df["cpu_load"].to_numpy(dtype=float)
    model = train_reap(
        X, y, feats, "cpu_load",
        ga_cfg=GAConfig(pop_size=8, n_generations=3, seed=0),
        verbose=False,
    )
    pred = model.predict(X[:10])
    assert pred.shape == (10,)
    assert "ENSEMBLE" in model.metrics


def test_env_step_and_baselines():
    cfg = ClusterConfig(time_horizon=10, n_visible=3, episode_max_steps=40)
    jobs = generate_job_trace(n_jobs=80, horizon=80, seed=1)
    env = ClusterEnv(cfg=cfg, job_trace=jobs, seed=1)
    obs = env.reset()
    assert obs.shape == env.state_shape
    for name in ("fifo", "sjf", "packer"):
        env2 = ClusterEnv(cfg=cfg, job_trace=jobs, seed=2)
        m = run_baseline(env2, name, max_steps=200)
        assert m["steps"] > 0


def test_cnn_policy_forward():
    cfg = ClusterConfig(time_horizon=10, n_visible=3, reap_channels=2)
    env = ClusterEnv(cfg=cfg, seed=0)
    s = env.reset()
    pol = CNNPolicy(in_channels=s.shape[0], action_dim=env.action_dim)
    x = torch.from_numpy(s[None]).float()
    logits, v = pol(x)
    assert logits.shape == (1, env.action_dim)
    assert v.shape == (1,)


def test_imitation_pipeline_tiny():
    cfg = ClusterConfig(time_horizon=8, n_visible=3, episode_max_steps=30)

    def factory(seed):
        return ClusterEnv(cfg=cfg, seed=seed)

    pol = CNNPolicy(in_channels=1, action_dim=cfg.n_visible + 1)
    icfg = ImitationConfig(n_episodes=3, max_steps=30, epochs=1, batch_size=32)
    s, a = collect_expert_trajectories(factory, icfg, verbose=False)
    assert s.shape[0] == a.shape[0] > 0
    train_imitation(pol, s, a, icfg, verbose=False)
