"""
End-to-end pipeline runner.

Equivalent to running:
    python -m data.synthetic_generator
    python -m src.reap.train --target cpu_load
    python -m src.reap.train --target memory_usage
    python -m src.deeprm.train --reap-channels 0 ...      # vanilla DeepRM_Plus
    python -m src.deeprm.train --reap-channels 2 ...      # DeepREAP
    python -m src.evaluation.benchmark
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def _run(cmd: list[str]) -> None:
    print("\n>>>", " ".join(cmd), flush=True)
    res = subprocess.run(cmd)
    if res.returncode != 0:
        sys.exit(res.returncode)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-data", action="store_true")
    ap.add_argument("--skip-reap", action="store_true")
    ap.add_argument("--skip-deeprm", action="store_true")
    ap.add_argument("--skip-deepreap", action="store_true")
    ap.add_argument("--skip-bench", action="store_true")
    ap.add_argument("--imitation-episodes", default="40")
    ap.add_argument("--ppo-updates", default="20")
    args = ap.parse_args()

    py = sys.executable

    if not args.skip_data:
        _run([py, "-m", "data.synthetic_generator"])

    if not args.skip_reap:
        _run([py, "-m", "src.reap.train", "--target", "cpu_load"])
        _run([py, "-m", "src.reap.train", "--target", "memory_usage"])

    if not args.skip_deeprm:
        _run([py, "-m", "src.deeprm.train",
              "--reap-channels", "0",
              "--imitation-episodes", args.imitation_episodes,
              "--ppo-updates", args.ppo_updates])

    if not args.skip_deepreap:
        _run([py, "-m", "src.deeprm.train",
              "--reap-channels", "2",
              "--imitation-episodes", args.imitation_episodes,
              "--ppo-updates", args.ppo_updates])

    if not args.skip_bench:
        _run([py, "-m", "src.evaluation.benchmark"])

    print("\n[pipeline] done. See results/ and models/ for artifacts.")


if __name__ == "__main__":
    main()
