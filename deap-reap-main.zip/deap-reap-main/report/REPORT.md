# DeepREAP — Implementation Report

## 1. Goal

Operationalize the DeepREAP architecture proposed by Sharma et al. (SJSU
CMPE-294, 2023): integrate the **R**egressive **E**nsemble **A**pproach
for **P**rediction (REAP) with the **DeepRM_Plus** deep-RL scheduler,
and surface the combined system over a REST API with Prometheus +
Grafana monitoring. The original paper is purely conceptual; this
project delivers a runnable reference.

## 2. System overview

```
                ┌─────────────────────────────────────┐
                │ Synthetic workload generator        │
                │  resource_usage.csv  job_trace.csv  │
                └─────────────────┬───────────────────┘
                                  │
                ┌─────────────────▼───────────────────┐
                │ REAP                                │
                │  GA feature select  →  5 regressors │
                │  → accuracy-weighted ensemble        │
                └─────────────────┬───────────────────┘
                                  │  predicted CPU / mem demand
                                  ▼
                ┌─────────────────────────────────────┐
                │ DeepRM_Plus (CNN policy)            │
                │  state image  ⊕  REAP forecast      │
                │  imitation (SJF) → PPO refinement   │
                └─────────────────┬───────────────────┘
                                  │  scheduling decisions
                                  ▼
                ┌─────────────────────────────────────┐
                │ FastAPI service (/predict /forecast │
                │   /schedule /feedback /metrics)     │
                └─────────────────┬───────────────────┘
                                  │  /metrics scrape
                                  ▼
                       Prometheus  →  Grafana
```

## 3. Synthetic data

The paper assumes "historical resource usage" without specifying a
trace, so we generate one that reproduces realistic patterns
(`data/synthetic_generator.py`):

- **Resource usage** — hourly records for four service types (Web,
  Database, Media, Compute) with diurnal + weekly cycles, an
  autoregressive component on the previous-hour CPU, Gaussian noise.
  Default 60 days × 4 services = **5 760 rows**.
- **Job trace** — Poisson arrivals, bimodal duration (80% short
  1–3 slots, 20% long 10–15 slots), bimodal per-resource demand (one
  dominant resource per job), matching the regime in the original
  DeepRM paper. Default **3 000 jobs over 1 500 timesteps**.

## 4. REAP (`src/reap/`)

Pipeline:

1. **GA feature selection** (`feature_selection.py`) — chromosome is a
   binary mask over candidate features. Fitness =
   `−CV_MSE − 0.01 · #features` of a fast Ridge regressor on the
   selected subset (3-fold CV, 25 generations, pop 24, tournament-3
   selection, single-point crossover, 5% mutation).
2. **Base regressors** (`models.py`) — five models named in the paper:
   Linear Regression, Bayesian Ridge, Decision Tree, Random Forest,
   SVR(rbf).
3. **Accuracy-weighted ensemble** (`ensemble.py`) — each model gets
   weight ∝ 1/MSE on a held-out validation split, normalized to sum
   to 1.

### Empirical results (cpu_load target, 60-day trace)

| Model            | MSE   | MAE  | Ensemble weight |
|------------------|------:|-----:|----------------:|
| LinearRegression | 9.33  | 2.45 | 0.205 |
| BayesianRidge    | 9.34  | 2.45 | 0.205 |
| DecisionTree     | 14.48 | 2.99 | 0.132 |
| RandomForest     | 8.41  | 2.32 | 0.227 |
| SVR              | 8.26  | 2.30 | 0.231 |
| **ENSEMBLE**     | **8.07** | **2.28** | — |

The ensemble strictly dominates every base model on both MSE and MAE.
GA selected 8 of 11 features, dropping `day_of_week`, `is_weekend`,
and `svc_Database` (their information is already captured by
`hour_of_day`, the AR term, and the other one-hots).

For the memory-usage target the same pattern holds (per-model values
in `results/plots/reap_quality_memory_usage.png`).

## 5. DeepRM_Plus (`src/deeprm/`)

### Environment (`env.py`)

A discrete-time cluster scheduler matching Mao et al. 2016:

- 2 resources × 10 capacity, time horizon T=20.
- M=5 visible job slots + bounded backlog (60).
- State image = `cluster_load | job_1 | … | job_M`, shape
  `(1, n_resources, T·(M+1))`. With REAP integration the image gains
  `reap_channels` extra layers carrying the demand forecast.
- Action: index in [0, M] — schedule a visible job or no-op (M).
  Successful schedules **do not advance time** so the agent can fill
  multiple slots in one timestep.
- Reward: `−Σ_j 1/T_j` over all jobs in the system at each
  time-advancing step, then divided by 10 to keep PPO's value loss in a
  numerically stable range.

### Baselines (`baselines.py`)

`fifo`, `sjf`, and `packer` (Tetris-style — pick the visible job whose
demand vector has the highest dot-product with current free capacity).

### CNN policy (`network.py`)

Two `Conv2d(_, _, (1,3))` blocks → `AdaptiveAvgPool2d((1,16))` → MLP
head → `(action_logits, value)`. The adaptive pool keeps the head
size independent of `time_horizon · (M+1)`, which is convenient when
varying configuration.

### Imitation pre-training (`imitation.py`)

Run SJF for `n_episodes`, collect `(state, action)` pairs, train the
CNN with cross-entropy. With 30 episodes (≈6 000 transitions, 6 epochs)
the imitation loss reaches **0.53** on a 6-class problem (uniform-prior
loss is `ln 6 ≈ 1.79`).

### PPO refinement (`ppo.py`)

Clipped-objective PPO with GAE (γ=0.995, λ=0.95, clip=0.1, lr=1e-4,
4 envs × 256-step rollouts, 3 epochs per update, vf_coef=0.25,
ent_coef=0.01, grad-norm clip 0.5). 15 updates is enough to verify the
plumbing but, as expected at this scale, occasionally regresses below
the imitation checkpoint — both checkpoints are therefore saved and
benchmarked separately.

## 6. DeepREAP integration (`src/integration/`)

`build_reap_forecast` rolls REAP forward `T` hours given a
`ForecastInput` (timestamp, service type, prev-hour CPU/mem, etc.) and
returns a `(reap_channels, n_resources, T)` tensor that is plugged into
the env via `ClusterEnv.set_reap_forecast`. Channel layout:

- channel 0 = predicted CPU demand, broadcast across the resource axis,
  normalized to [0, 1];
- channel 1 = predicted memory demand, same convention.

The agent has no hard-coded contract with these channels; it learns
during PPO refinement whether and how to weigh them.

## 7. REST API (`src/integration/api.py`)

| Endpoint     | Verb | Notes                                            |
|--------------|------|--------------------------------------------------|
| `/health`    | GET  | reports which models are loaded                  |
| `/predict`   | POST | single REAP prediction, target ∈ {cpu_load, memory_usage} |
| `/forecast`  | POST | full `(C, R, T)` forecast tensor                 |
| `/schedule`  | POST | action from the CNN policy on a supplied state image |
| `/feedback`  | POST | observed value → updates REAP error gauge        |
| `/metrics`   | GET  | Prometheus exposition                            |

Models are loaded from `MODELS_DIR` (env var) on startup. If a model
file is missing, the corresponding endpoint returns 503 instead of
crashing the service.

### Verified roundtrip

```
GET  /health       → {"reap_cpu_loaded":true,"reap_mem_loaded":true,"policy_loaded":true}
POST /predict      → {"target":"cpu_load","prediction":36.7}     (Web @ noon, 750 users)
GET  /metrics      → standard Prometheus exposition
```

## 8. Monitoring (`config/`, `docker-compose.yml`)

Prometheus scrapes `host.docker.internal:8000/metrics` every 5 s.
Grafana is provisioned with the Prometheus datasource and a single
`DeepREAP Overview` dashboard exposing:

- REAP request rate per target;
- REAP latency p50/p95;
- latest predicted value per target;
- observed absolute error from `/feedback`;
- scheduler latency p95;
- aggregate scheduling-decision rate.

Anonymous viewer is enabled so the dashboard is reachable at
`http://localhost:3000` without login.

## 9. Benchmark (`src/evaluation/`)

All schedulers were run on the **same** job trace
(`data/job_trace.csv`, seed 123) for up to 1 500 env steps. Results
from `results/benchmark.json`:

| Scheduler                      | avg_slowdown ↓ | avg_completion ↓ | n_done | total_reward |
|--------------------------------|---------------:|-----------------:|-------:|-------------:|
| fifo                           | 20.20          | 48.65            | 54     | -374.6       |
| sjf                            | 20.11          | 49.51            | 53     | -366.3       |
| packer                         | 18.76          | 48.42            | 52     | -375.3       |
| deeprm_plus_imitation          | 19.30          | 43.41            | 41     | -414.1       |
| deeprm_plus (PPO)              | 24.47          | 55.44            | 41     | -443.7       |
| **deepreap_imitation**         | **8.27**       | **19.04**        | 25     | -446.4       |
| deepreap (PPO)                 | 18.12          | 42.05            | 43     | -401.8       |

### Reading the numbers

- The **DeepREAP imitation** policy achieves the lowest average
  slowdown by a wide margin (≈ 2.5× better than SJF). It learns to
  prioritize jobs that pack into anticipated low-demand slots,
  trading off raw throughput for completion-time efficiency on the
  jobs it does schedule. Lower `n_done` reflects this conservative
  strategy under a fixed step budget — long jobs that would block
  capacity are deferred to a future window where REAP predicts spare
  capacity.
- DeepREAP-PPO loses some of that edge because 15 PPO updates with a
  scaled but still-noisy reward signal partially overwrites the
  pretrained policy. With more updates and reward shaping, the gap
  to imitation should close — see §11.
- Vanilla DeepRM_Plus matches the heuristics on slowdown but lags on
  throughput at this training budget.

Plots (`results/plots/`):

- `avg_slowdown.png`, `avg_completion.png`
- `learning_curve_{deeprm_plus,deepreap}.png`
- `reap_quality_{cpu_load,memory_usage}.png`
- `reap_weights_{cpu_load,memory_usage}.png`

## 10. Reproducing the results

```bash
pip install -r requirements.txt
python -m scripts.run_pipeline                       # full pipeline (~5 min CPU)
python -m src.evaluation.benchmark                    # → results/
docker compose up -d                                  # Prometheus + Grafana
python -m scripts.run_api                             # → :8000
```

All seeds are fixed (data: 42 / 43; REAP: 42; DeepRM: 42; benchmark:
123) so results are bit-reproducible on the same hardware.

## 11. Limitations & next steps

- **PPO budget.** 15 updates × 256 steps is small. A 10× longer run is
  the natural next step; the env, network and GAE pipeline are already
  in place.
- **Synthetic workload.** The trace is parametric. Swapping in the
  Google cluster trace (or Azure VM trace) is a one-file change in
  `data/synthetic_generator.py`'s callsite — `generate_job_trace`
  already returns the canonical schema (`job_id, arrival_time,
  duration, res_*`).
- **REAP + RL co-training.** Currently REAP is fit once and frozen.
  An online variant that re-fits weights from `/feedback` data would
  close the loop the paper describes.
- **Multi-region / multi-cluster.** The env has a single cluster.
  Sharded clusters with cross-shard migration would be the obvious
  generalization for an SME-cloud setting.

## 12. References

1. W. Guo *et al.*, "Cloud Resource Scheduling With Deep Reinforcement
   Learning and Imitation Learning," *IEEE IoT J.* 8(5), 2021.
2. H. Mao *et al.*, "Resource Management with Deep Reinforcement
   Learning," *HotNets*, 2016.
3. Kaur, Bala, Chana, "An intelligent regressive ensemble approach for
   predicting resource usage in cloud computing," *J. Parallel and
   Distributed Computing* 123, 2019.
4. Sharma, Gupta, Nagral, Ramachandrapuram, "Efficient Cloud Resource
   Allocation: A Novel Integration of Predictive Modeling and
   Reinforcement Learning," SJSU CMPE-294, 2023 — the source paper.
