"""
Benchmark DeepREAP against heuristic baselines and the vanilla DeepRM_Plus.

Outputs
-------
results/benchmark.json   raw metric dict per scheduler
results/plots/*.png      bar charts and learning-curve plots
results/plots/reap_*.png REAP prediction quality plots
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch

from src.deeprm.baselines import run_baseline
from src.deeprm.env import ClusterConfig, ClusterEnv
from src.deeprm.network import CNNPolicy
from src.reap.ensemble import REAPModel


# ---------- scheduler runners ---------------------------------------
def run_policy(env: ClusterEnv, policy: CNNPolicy, max_steps: int = 5000) -> dict:
    s = env.reset()
    total = 0.0
    steps = 0
    policy.eval()
    while steps < max_steps:
        x = torch.from_numpy(s[None]).float()
        with torch.no_grad():
            logits, _ = policy(x)
        a = int(torch.argmax(logits, dim=-1).item())
        s, r, done, _ = env.step(a)
        total += r
        steps += 1
        if done:
            break
    m = env.metrics()
    m["total_reward"] = total
    m["steps"] = steps
    return m


def _make_env(trace_path: str | None, reap_channels: int, seed: int) -> ClusterEnv:
    cfg = ClusterConfig(reap_channels=reap_channels)
    trace = pd.read_csv(trace_path) if trace_path else None
    return ClusterEnv(cfg=cfg, job_trace=trace, seed=seed)


def _load_policy(path: Path) -> tuple[CNNPolicy, dict]:
    ckpt = torch.load(path, map_location="cpu", weights_only=False)
    policy = CNNPolicy(in_channels=ckpt["in_channels"], action_dim=ckpt["action_dim"])
    policy.load_state_dict(ckpt["policy"])
    return policy, ckpt


# ---------- plots ---------------------------------------------------
def plot_bars(results: dict, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)

    schedulers = list(results.keys())
    metrics = ["avg_slowdown", "avg_completion"]

    for metric in metrics:
        values = [results[s].get(metric, 0.0) for s in schedulers]
        plt.figure(figsize=(8, 4))
        bars = plt.bar(schedulers, values, color="steelblue", edgecolor="black")
        plt.ylabel(metric)
        plt.title(f"{metric} across schedulers")
        plt.xticks(rotation=15)
        for b, v in zip(bars, values):
            plt.text(b.get_x() + b.get_width() / 2, v, f"{v:.2f}",
                     ha="center", va="bottom", fontsize=9)
        plt.tight_layout()
        out_path = out_dir / f"{metric}.png"
        plt.savefig(out_path, dpi=120)
        plt.close()
        print(f"[plot] wrote {out_path}")


def plot_learning_curve(history_path: Path, out_dir: Path, name: str) -> None:
    if not history_path.exists():
        return
    with open(history_path) as f:
        h = json.load(f)
    if not h.get("update"):
        return
    plt.figure(figsize=(8, 4))
    plt.plot(h["update"], h["mean_reward"], marker="o", linewidth=1.2)
    plt.xlabel("PPO update")
    plt.ylabel("mean episode reward")
    plt.title(f"PPO learning curve — {name}")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    out = out_dir / f"learning_curve_{name}.png"
    plt.savefig(out, dpi=120)
    plt.close()
    print(f"[plot] wrote {out}")


def plot_reap_quality(reap_metrics_path: Path, out_dir: Path) -> None:
    if not reap_metrics_path.exists():
        return
    with open(reap_metrics_path) as f:
        d = json.load(f)
    metrics = d["metrics"]
    names = list(metrics.keys())
    mses = [metrics[n]["mse"] for n in names]
    maes = [metrics[n]["mae"] for n in names]

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].bar(names, mses, color="indianred", edgecolor="black")
    axes[0].set_title(f"REAP MSE — {d['target']}")
    axes[0].set_ylabel("MSE")
    axes[0].tick_params(axis="x", rotation=20)

    axes[1].bar(names, maes, color="seagreen", edgecolor="black")
    axes[1].set_title(f"REAP MAE — {d['target']}")
    axes[1].set_ylabel("MAE")
    axes[1].tick_params(axis="x", rotation=20)
    plt.tight_layout()
    out = out_dir / f"reap_quality_{d['target']}.png"
    plt.savefig(out, dpi=120)
    plt.close()
    print(f"[plot] wrote {out}")


def plot_reap_weights(reap_metrics_path: Path, out_dir: Path) -> None:
    if not reap_metrics_path.exists():
        return
    with open(reap_metrics_path) as f:
        d = json.load(f)
    w = d["weights"]
    plt.figure(figsize=(7, 4))
    plt.bar(list(w.keys()), list(w.values()), color="slateblue", edgecolor="black")
    plt.title(f"REAP ensemble weights — {d['target']}")
    plt.ylabel("weight")
    plt.xticks(rotation=20)
    plt.tight_layout()
    out = out_dir / f"reap_weights_{d['target']}.png"
    plt.savefig(out, dpi=120)
    plt.close()
    print(f"[plot] wrote {out}")


# ---------- main ----------------------------------------------------
def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--job-trace", default="data/job_trace.csv")
    ap.add_argument("--results", default="results")
    ap.add_argument("--seed", type=int, default=123)
    ap.add_argument("--max-steps", type=int, default=4000)
    ap.add_argument("--deeprm-path", default="models/deeprm/deeprm_plus.pt")
    ap.add_argument("--deepreap-path", default="models/deeprm/deepreap.pt")
    ap.add_argument("--reap-cpu-metrics", default="models/reap/reap_cpu_load_metrics.json")
    ap.add_argument("--reap-mem-metrics", default="models/reap/reap_memory_usage_metrics.json")
    args = ap.parse_args()

    out = Path(args.results)
    plots = out / "plots"
    out.mkdir(parents=True, exist_ok=True)
    plots.mkdir(parents=True, exist_ok=True)

    results: dict[str, dict] = {}

    # heuristic baselines (no REAP forecast channel)
    for name in ["fifo", "sjf", "packer"]:
        env = _make_env(args.job_trace, reap_channels=0, seed=args.seed)
        m = run_baseline(env, name, max_steps=args.max_steps)
        results[name] = m
        print(f"[bench] {name:12s}  {m}")

    # vanilla DeepRM_Plus -- evaluate both imitation and PPO checkpoints
    for label, ckpt_path, reap_ch in [
        ("deeprm_plus_imitation", "models/deeprm/deeprm_plus_imitation.pt", 0),
        ("deeprm_plus", args.deeprm_path, 0),
        ("deepreap_imitation", "models/deeprm/deepreap_imitation.pt", 2),
        ("deepreap", args.deepreap_path, 2),
    ]:
        p = Path(ckpt_path)
        if not p.exists():
            continue
        ckpt = torch.load(p, map_location="cpu", weights_only=False)
        # use the reap_channels the checkpoint was actually trained with
        reap_ch_actual = ckpt["cfg"].get("reap_channels", reap_ch)
        env = _make_env(args.job_trace, reap_channels=reap_ch_actual, seed=args.seed)
        policy, _ = _load_policy(p)
        m = run_policy(env, policy, max_steps=args.max_steps)
        results[label] = m
        print(f"[bench] {label:24s}  {m}")

    # serialize
    with open(out / "benchmark.json", "w") as f:
        json.dump(results, f, indent=2)

    # plots
    plot_bars(results, plots)
    plot_learning_curve(Path("models/deeprm/deeprm_plus_history.json"), plots, "deeprm_plus")
    plot_learning_curve(Path("models/deeprm/deepreap_history.json"), plots, "deepreap")
    plot_reap_quality(Path(args.reap_cpu_metrics), plots)
    plot_reap_quality(Path(args.reap_mem_metrics), plots)
    plot_reap_weights(Path(args.reap_cpu_metrics), plots)
    plot_reap_weights(Path(args.reap_mem_metrics), plots)


if __name__ == "__main__":
    main()
