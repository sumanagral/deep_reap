"""
REAP ensemble: accuracy-weighted combination of base regressors.

Weights are inverse-validation-MSE, normalized to sum to 1
(so models with lower error get more influence in the final
prediction). This matches the description in the DeepREAP paper:
    "regression models weighted by accuracy".
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import joblib
import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from .feature_selection import GAConfig, select_features
from .models import NamedRegressor, build_default_models


@dataclass
class REAPModel:
    target_name: str
    feature_names: list[str]
    feature_mask: np.ndarray
    selected_features: list[str]
    scaler: StandardScaler
    models: list[NamedRegressor]
    weights: np.ndarray
    metrics: dict[str, dict[str, float]] = field(default_factory=dict)

    def predict(self, X_raw: np.ndarray) -> np.ndarray:
        X = X_raw[:, self.feature_mask.astype(bool)]
        X = self.scaler.transform(X)
        preds = np.stack([m.predict(X) for m in self.models])  # (n_models, n_samples)
        return (self.weights[:, None] * preds).sum(axis=0)

    def per_model_predict(self, X_raw: np.ndarray) -> dict[str, np.ndarray]:
        X = X_raw[:, self.feature_mask.astype(bool)]
        X = self.scaler.transform(X)
        return {m.name: m.predict(X) for m in self.models}

    # --- persistence ---
    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(
            {
                "target_name": self.target_name,
                "feature_names": self.feature_names,
                "feature_mask": self.feature_mask,
                "selected_features": self.selected_features,
                "scaler": self.scaler,
                "models": self.models,
                "weights": self.weights,
                "metrics": self.metrics,
            },
            path,
        )

    @staticmethod
    def load(path: str | Path) -> "REAPModel":
        d = joblib.load(path)
        return REAPModel(**d)


def train_reap(
    X: np.ndarray,
    y: np.ndarray,
    feature_names: list[str],
    target_name: str,
    test_size: float = 0.2,
    seed: int = 42,
    ga_cfg: GAConfig | None = None,
    verbose: bool = True,
) -> REAPModel:
    """
    1. GA feature selection on TRAIN split
    2. Standardize selected features
    3. Train each base model
    4. Weight by 1/validation_MSE, normalized
    """
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=test_size, random_state=seed
    )

    if verbose:
        print(f"[REAP] target={target_name}  train={len(y_tr)} test={len(y_te)}")
        print(f"[REAP] running GA feature selection over {X.shape[1]} features...")

    mask, selected, fit = select_features(
        X_tr, y_tr,
        feature_names=feature_names,
        cfg=ga_cfg or GAConfig(seed=seed),
        verbose=verbose,
    )
    if verbose:
        print(f"[REAP] selected {len(selected)}/{X.shape[1]} features  fit={fit:.4f}")
        print(f"[REAP] features: {selected}")

    Xs_tr = X_tr[:, mask.astype(bool)]
    Xs_te = X_te[:, mask.astype(bool)]
    scaler = StandardScaler().fit(Xs_tr)
    Xs_tr_s = scaler.transform(Xs_tr)
    Xs_te_s = scaler.transform(Xs_te)

    models = build_default_models(seed=seed)
    metrics: dict[str, dict[str, float]] = {}
    val_mses = []
    for m in models:
        m.fit(Xs_tr_s, y_tr)
        pred = m.predict(Xs_te_s)
        mse = float(mean_squared_error(y_te, pred))
        mae = float(mean_absolute_error(y_te, pred))
        metrics[m.name] = {"mse": mse, "mae": mae}
        val_mses.append(mse)
        if verbose:
            print(f"[REAP]   {m.name:18s}  mse={mse:7.4f}  mae={mae:7.4f}")

    inv = 1.0 / (np.array(val_mses) + 1e-8)
    weights = inv / inv.sum()

    # ensemble metrics
    preds = np.stack([m.predict(Xs_te_s) for m in models])
    ens = (weights[:, None] * preds).sum(axis=0)
    ens_mse = float(mean_squared_error(y_te, ens))
    ens_mae = float(mean_absolute_error(y_te, ens))
    metrics["ENSEMBLE"] = {"mse": ens_mse, "mae": ens_mae}
    if verbose:
        print(f"[REAP]   ENSEMBLE           mse={ens_mse:7.4f}  mae={ens_mae:7.4f}")
        print(f"[REAP]   weights={dict(zip([m.name for m in models], weights.round(3)))}")

    return REAPModel(
        target_name=target_name,
        feature_names=feature_names,
        feature_mask=mask,
        selected_features=selected,
        scaler=scaler,
        models=models,
        weights=weights,
        metrics=metrics,
    )


def metrics_to_json(model: REAPModel, path: str | Path) -> None:
    """Serialize per-model + ensemble metrics for the report."""
    payload: dict[str, Any] = {
        "target": model.target_name,
        "selected_features": model.selected_features,
        "weights": dict(zip([m.name for m in model.models], model.weights.tolist())),
        "metrics": model.metrics,
    }
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(payload, f, indent=2)
