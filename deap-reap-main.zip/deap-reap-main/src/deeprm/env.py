"""
Gym-compatible cluster scheduling environment for DeepRM_Plus.

State representation (image-like, as in Mao et al. 2016):
    - Cluster image     : (n_resources, time_horizon)         currently scheduled load
    - Job slots         : M jobs x (n_resources, time_horizon)  visible queue
    - Backlog count     : scalar  (jobs waiting beyond the visible window)
    - Optional: REAP demand forecast appended as an extra channel of the
                cluster image (filled by the integration layer).

Actions: discrete index in [0, M].
    - 0..M-1 : schedule the j-th visible job (skip if it does not fit)
    - M      : "no-op" -> advance one timestep

Reward (per timestep): -sum_{j in system} 1/T_j  (penalizes slowdown,
matching the reward used in the DeepRM paper).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd


@dataclass
class ClusterConfig:
    n_resources: int = 2
    res_capacity: int = 10           # capacity per resource
    time_horizon: int = 20           # T: how far ahead the image looks
    n_visible: int = 5               # M: number of visible job slots
    max_job_len: int = 15
    max_backlog: int = 60
    new_job_rate: float = 0.7        # P(new job per timestep when env steps)
    episode_max_steps: int = 200
    reap_channels: int = 0           # appended channels for REAP forecast (optional)


@dataclass
class Job:
    job_id: int
    arrival_time: int
    duration: int
    demand: np.ndarray        # shape (n_resources,)
    started_time: int = -1    # -1 if not yet scheduled
    finished_time: int = -1


class ClusterEnv:
    """Lightweight gym-style env (no external Gym dep required)."""

    def __init__(
        self,
        cfg: ClusterConfig | None = None,
        job_trace: pd.DataFrame | None = None,
        seed: int = 0,
    ):
        self.cfg = cfg or ClusterConfig()
        self.rng = np.random.default_rng(seed)
        self._seed = seed
        self._job_trace = job_trace
        self.reset()

    # ------------------------------------------------------------------ public
    @property
    def action_dim(self) -> int:
        return self.cfg.n_visible + 1  # +1 for no-op

    @property
    def state_shape(self) -> tuple[int, int, int]:
        # combined image: cluster | M*job_slot | (optional REAP)
        h = self.cfg.n_resources
        w = self.cfg.time_horizon * (1 + self.cfg.n_visible)
        c = 1 + self.cfg.reap_channels
        return (c, h, w)

    def reset(self, seed: int | None = None) -> np.ndarray:
        if seed is not None:
            self.rng = np.random.default_rng(seed)
            self._seed = seed
        c = self.cfg
        # cluster_load[r, t]: load on resource r at offset t from current time
        self.cluster_load = np.zeros((c.n_resources, c.time_horizon), dtype=np.float32)
        self.visible: list[Job | None] = [None] * c.n_visible
        self.backlog: list[Job] = []
        self.in_progress: list[Job] = []
        self.finished: list[Job] = []
        self.t = 0
        self._next_job_id = 0
        self._steps = 0
        self.reap_forecast = np.zeros(
            (c.reap_channels, c.n_resources, c.time_horizon), dtype=np.float32
        )
        # if a fixed trace is supplied, sort by arrival_time
        if self._job_trace is not None:
            self._trace_idx = 0
            self._trace = self._job_trace.sort_values("arrival_time").reset_index(drop=True)
        else:
            self._trace = None
        # bootstrap the queue
        self._spawn_arrivals(initial=True)
        return self._observation()

    def step(self, action: int) -> tuple[np.ndarray, float, bool, dict]:
        assert 0 <= action < self.action_dim
        info: dict = {"scheduled": None, "advanced": False}

        if action < self.cfg.n_visible:
            job = self.visible[action]
            if job is not None and self._can_schedule(job):
                self._schedule(job, slot=action)
                info["scheduled"] = job.job_id
                # IMPORTANT: do NOT advance time after a successful schedule;
                # let the agent fill more slots in the same timestep.
                obs = self._observation()
                reward = 0.0
                done = self._steps >= self.cfg.episode_max_steps and not self._has_work()
                self._steps += 1
                return obs, reward, done, info
            # invalid action -> no-op with small penalty
            info["invalid"] = True

        # no-op: advance one timestep
        info["advanced"] = True
        self._advance_one_step()
        reward = self._reward()
        done = self._steps >= self.cfg.episode_max_steps or not self._has_work()
        self._steps += 1
        return self._observation(), reward, done, info

    # ----------------------------------------------------------- core dynamics
    def _has_work(self) -> bool:
        return (
            any(s is not None for s in self.visible)
            or len(self.backlog) > 0
            or len(self.in_progress) > 0
            or (self._trace is not None and self._trace_idx < len(self._trace))
        )

    def _can_schedule(self, job: Job) -> bool:
        c = self.cfg
        if job.duration > c.time_horizon:
            return False
        # find the earliest start offset where capacity holds
        free = c.res_capacity - self.cluster_load
        for t0 in range(c.time_horizon - job.duration + 1):
            window = free[:, t0 : t0 + job.duration]
            if np.all(window >= job.demand[:, None]):
                job._start_offset = t0  # type: ignore[attr-defined]
                return True
        return False

    def _schedule(self, job: Job, slot: int) -> None:
        t0 = getattr(job, "_start_offset", 0)
        self.cluster_load[:, t0 : t0 + job.duration] += job.demand[:, None]
        job.started_time = self.t + t0
        self.in_progress.append(job)
        self.visible[slot] = None
        self._refill_visible()

    def _refill_visible(self) -> None:
        for i, slot in enumerate(self.visible):
            if slot is None and self.backlog:
                self.visible[i] = self.backlog.pop(0)

    def _advance_one_step(self) -> None:
        # roll cluster image left by 1
        self.cluster_load = np.roll(self.cluster_load, -1, axis=1)
        self.cluster_load[:, -1] = 0.0
        if self.cfg.reap_channels:
            self.reap_forecast = np.roll(self.reap_forecast, -1, axis=2)
            self.reap_forecast[:, :, -1] = 0.0
        self.t += 1
        # finish jobs whose end time has passed
        still = []
        for j in self.in_progress:
            if j.started_time + j.duration <= self.t:
                j.finished_time = j.started_time + j.duration
                self.finished.append(j)
            else:
                still.append(j)
        self.in_progress = still
        # spawn new arrivals
        self._spawn_arrivals()

    def _reward(self) -> float:
        # -sum 1/T_j over jobs currently in the system (visible, backlog, in_progress).
        # Scaled by an empirical factor so the per-step magnitude lands near
        # O(1), which keeps PPO's value loss in a sane range.
        total = 0.0
        for j in self.in_progress:
            total += 1.0 / max(j.duration, 1)
        for j in self.visible:
            if j is not None:
                total += 1.0 / max(j.duration, 1)
        for j in self.backlog:
            total += 1.0 / max(j.duration, 1)
        return -total / 10.0

    # ---------------------------------------------------------------- arrivals
    def _spawn_arrivals(self, initial: bool = False) -> None:
        c = self.cfg
        if self._trace is not None:
            while (
                self._trace_idx < len(self._trace)
                and int(self._trace.iloc[self._trace_idx]["arrival_time"]) <= self.t
            ):
                row = self._trace.iloc[self._trace_idx]
                self._trace_idx += 1
                demand = np.array(
                    [int(row[f"res_{r}"]) for r in range(c.n_resources)],
                    dtype=np.float32,
                )
                self._enqueue(
                    Job(
                        job_id=int(row["job_id"]),
                        arrival_time=int(row["arrival_time"]),
                        duration=int(row["duration"]),
                        demand=demand,
                    )
                )
        else:
            n_new = 1 + (1 if initial else 0)
            for _ in range(n_new):
                if self.rng.random() > c.new_job_rate and not initial:
                    continue
                duration = int(self.rng.integers(1, c.max_job_len + 1))
                dom = int(self.rng.integers(0, c.n_resources))
                demand = np.zeros(c.n_resources, dtype=np.float32)
                for r in range(c.n_resources):
                    if r == dom:
                        demand[r] = self.rng.integers(int(0.25 * c.res_capacity) + 1, c.res_capacity + 1)
                    else:
                        demand[r] = self.rng.integers(1, int(0.25 * c.res_capacity) + 2)
                self._enqueue(
                    Job(
                        job_id=self._next_job_id,
                        arrival_time=self.t,
                        duration=duration,
                        demand=demand,
                    )
                )
                self._next_job_id += 1

    def _enqueue(self, job: Job) -> None:
        for i, slot in enumerate(self.visible):
            if slot is None:
                self.visible[i] = job
                return
        if len(self.backlog) < self.cfg.max_backlog:
            self.backlog.append(job)
        # else: drop (the original DeepRM also drops over-capacity backlog)

    # ----------------------------------------------------------- observation
    def _observation(self) -> np.ndarray:
        c = self.cfg
        # base channel: [cluster_image | job_1 | job_2 | ... | job_M]
        slots = []
        for j in self.visible:
            img = np.zeros((c.n_resources, c.time_horizon), dtype=np.float32)
            if j is not None:
                d = min(j.duration, c.time_horizon)
                img[:, :d] = j.demand[:, None]
            slots.append(img)
        base = np.concatenate([self.cluster_load] + slots, axis=1)  # (R, T*(M+1))
        base = base[None, :, :]  # (1, R, T*(M+1))

        if c.reap_channels:
            # tile the forecast across the same time axis as cluster image,
            # leaving the visible-slot region zero (it carries job demand only)
            tiled = np.zeros_like(base).repeat(c.reap_channels, axis=0)
            tiled[:, :, : c.time_horizon] = self.reap_forecast
            obs = np.concatenate([base, tiled], axis=0)
        else:
            obs = base
        return obs.astype(np.float32)

    # ----------------------------------------------------------------- helpers
    def set_reap_forecast(self, forecast: np.ndarray) -> None:
        """forecast: (reap_channels, n_resources, time_horizon)"""
        c = self.cfg
        assert forecast.shape == (c.reap_channels, c.n_resources, c.time_horizon)
        self.reap_forecast = forecast.astype(np.float32)

    def metrics(self) -> dict:
        if not self.finished:
            return {"avg_slowdown": 0.0, "avg_completion": 0.0, "n_done": 0}
        slow = []
        comp = []
        for j in self.finished:
            wait = j.started_time - j.arrival_time
            comp_time = j.finished_time - j.arrival_time
            slowdown = comp_time / max(j.duration, 1)
            slow.append(slowdown)
            comp.append(comp_time)
        return {
            "avg_slowdown": float(np.mean(slow)),
            "avg_completion": float(np.mean(comp)),
            "n_done": len(self.finished),
            "n_remaining": (
                len(self.in_progress)
                + len(self.backlog)
                + sum(1 for s in self.visible if s is not None)
            ),
        }
