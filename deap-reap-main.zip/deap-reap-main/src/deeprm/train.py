"""
DeepRM_Plus training entrypoint.

  1. Imitation pre-training from SJF expert.
  2. PPO refinement.
  3. Save the trained policy.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import torch

from .env import ClusterConfig, ClusterEnv
from .imitation import ImitationConfig, collect_expert_trajectories, train_imitation
from .network import CNNPolicy
from .ppo import PPOConfig, train_ppo


def make_env_factory(job_trace_path: str | None, cfg: ClusterConfig):
    trace = pd.read_csv(job_trace_path) if job_trace_path else None

    def _factory(seed: int) -> ClusterEnv:
        return ClusterEnv(cfg=cfg, job_trace=trace, seed=seed)

    return _factory


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--job-trace", default="data/job_trace.csv",
                    help="path to job trace CSV; pass '' for synthetic-on-the-fly")
    ap.add_argument("--out", default="models/deeprm")
    ap.add_argument("--reap-channels", type=int, default=0,
                    help="extra channels for REAP forecast (0 = vanilla DeepRM_Plus)")
    ap.add_argument("--imitation-episodes", type=int, default=60)
    ap.add_argument("--ppo-updates", type=int, default=40)
    ap.add_argument("--n-resources", type=int, default=2)
    ap.add_argument("--horizon", type=int, default=20)
    ap.add_argument("--n-visible", type=int, default=5)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--device", default="cpu")
    args = ap.parse_args()

    cfg = ClusterConfig(
        n_resources=args.n_resources,
        time_horizon=args.horizon,
        n_visible=args.n_visible,
        reap_channels=args.reap_channels,
    )
    env_factory = make_env_factory(args.job_trace or None, cfg)

    sample = env_factory(args.seed)
    in_channels = sample.state_shape[0]
    print(f"[train_deeprm] state_shape={sample.state_shape}  action_dim={sample.action_dim}")

    policy = CNNPolicy(in_channels=in_channels, action_dim=sample.action_dim)

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    tag = "deepreap" if args.reap_channels > 0 else "deeprm_plus"

    def _save(name: str) -> None:
        torch.save(
            {"policy": policy.state_dict(), "cfg": cfg.__dict__,
             "in_channels": in_channels, "action_dim": sample.action_dim},
            out / f"{name}.pt",
        )
        print(f"[train_deeprm] saved {out / (name + '.pt')}")

    # ---------- imitation -----------------------------------------
    imi_cfg = ImitationConfig(n_episodes=args.imitation_episodes)
    print("[train_deeprm] collecting SJF expert trajectories...")
    s, a = collect_expert_trajectories(env_factory, imi_cfg, seed=args.seed)
    print(f"[train_deeprm] expert buffer: states={s.shape}  actions={a.shape}")
    train_imitation(policy, s, a, imi_cfg, device=args.device)
    # checkpoint after imitation -- a solid SJF-like baseline before any RL
    _save(f"{tag}_imitation")

    # ---------- PPO -----------------------------------------------
    ppo_cfg = PPOConfig(total_updates=args.ppo_updates)
    history = train_ppo(policy, env_factory, ppo_cfg, device=args.device, seed=args.seed)

    # ---------- save final ---------------------------------------
    _save(tag)
    with open(out / f"{tag}_history.json", "w") as f:
        json.dump(history, f, indent=2)


if __name__ == "__main__":
    main()
